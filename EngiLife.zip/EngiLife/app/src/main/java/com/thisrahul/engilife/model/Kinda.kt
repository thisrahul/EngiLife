package com.thisrahul.engilife.model

class Kinda(val img: Int, val isTagShow: Boolean, val tag: String)