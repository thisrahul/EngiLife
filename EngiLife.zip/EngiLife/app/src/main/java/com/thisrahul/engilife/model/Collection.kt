package com.thisrahul.engilife.model

class Collection(val img: Int, val title: String, val subTitle: String, val rating: String, val tag: String,val isTagShow : Boolean,val tagBackgroundColor : String)