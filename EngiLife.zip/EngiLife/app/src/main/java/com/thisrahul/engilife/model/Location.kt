package com.thisrahul.engilife.model

class Location(val name: String, val image: Int)