package com.thisrahul.engilife.model

class Wallet(val img : Int , val rs : String)